import { User } from './event.model';

export interface Activity {
  idActivity?: number;
  title: string;
  description: string;
  requirements: string;
  maxParticipants: number;
  eventId?: number;
   user?: User;
}