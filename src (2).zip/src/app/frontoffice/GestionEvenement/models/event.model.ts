import { Activity } from './activity.model';

export enum EventStatus {
  PENDING = 'PENDING',
  ACTIVE = 'ACTIVE',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED'
}

export enum CategoryEvent {
  CONFERENCE = 'CONFERENCE',
  WORKSHOP = 'WORKSHOP',
  WEBINAR = 'WEBINAR',
  NETWORKING = 'NETWORKING',
  HACKATHON = 'HACKATHON',
  OTHER = 'OTHER'
}

export interface User {
  id: number;
  name: string;
  lastName: string;
  role?: string;
}
export interface Event {
  idEvent?: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  eventStatus: EventStatus;
  location: string;
  capacity: number;
  currentParticipants?: number;
  imageUrl?: string;
  category: CategoryEvent;
  activities?: Activity[];
  createdAt?: string;
  updatedAt?: string;
 
}