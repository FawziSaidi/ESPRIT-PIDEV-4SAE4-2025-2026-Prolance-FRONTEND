import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  activeMenu: string = 'dashboard';

  menuItems = [
    { id: 'dashboard', icon: '📊', label: 'DASHBOARD', link: '#', route: '/admin/dashboard' },
    { id: 'profile',   icon: '👤', label: 'PROFILE',   link: '#', route: null },
    { id: 'users',     icon: '👥', label: 'USERS',     link: '#', route: '/admin/users' },
    { id: 'projet',    icon: '📋', label: 'PROJET',    link: '#', route: null },
    { id: 'forum',     icon: '💬', label: 'FORUM',     link: '#', route: '/admin/forum' }, // ← route activée
    { id: 'ads',       icon: '📷', label: 'ADS',       link: '#', route: '/admin/ads' },
    { id: 'evenement', icon: '📅', label: 'EVENTS',    link: '#', route: null },
    { id: 'cours',     icon: '🎓', label: 'COURSES',   link: '#', route: '/admin/cours' },
    { id: 'logout',    icon: '🔌', label: 'LOGOUT',    link: '#', route: null }
  ];

  constructor() { }

  ngOnInit(): void { }

  setActiveMenu(menuId: string): void {
    this.activeMenu = menuId;
    console.log('Menu actif:', menuId);
  }
}