import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class EmailNotificationService {

  // ✅ Remplace ces 3 valeurs avec tes IDs EmailJS
  // Obtenus sur https://www.emailjs.com après avoir créé ton compte
  private readonly SERVICE_ID  = 'service_6wd6yld';   // ex: service_abc123
  private readonly TEMPLATE_ID = 'template_0dkuola';  // ex: template_xyz456
  private readonly PUBLIC_KEY  = '0ty1N2DwIobb_bQtJ';    // ex: aBcDeFgHiJkLmNoPq

  private readonly EMAILJS_URL = 'https://api.emailjs.com/api/v1.0/email/send';

  sendDeleteNotification(params: {
    clientName:    string;
    clientEmail:   string;
    projectTitle:  string;
    projectBudget: number;
    projectCategory: string;
  }): void {

    const templateParams = {
      client_name:      params.clientName,
      client_email:     params.clientEmail,
      project_title:    params.projectTitle,
      project_budget:   params.projectBudget + ' TND',
      project_category: params.projectCategory,
      delete_date:      new Date().toLocaleDateString('fr-FR', {
                          day: '2-digit', month: 'long', year: 'numeric',
                          hour: '2-digit', minute: '2-digit'
                        }),
      admin_email:      'prolance2026@gmail.com'
    };

    const body = {
      service_id:  this.SERVICE_ID,
      template_id: this.TEMPLATE_ID,
      user_id:     this.PUBLIC_KEY,
      template_params: templateParams
    };

    // Envoi en arrière-plan — pas de blocage de l'UI
    fetch(this.EMAILJS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
      .then(res => {
        if (res.ok) {
          console.log('✅ Email de notification envoyé à l\'admin.');
        } else {
          res.text().then(t => console.warn('⚠️ EmailJS error:', t));
        }
      })
      .catch(err => console.error('❌ EmailJS network error:', err));
  }
}