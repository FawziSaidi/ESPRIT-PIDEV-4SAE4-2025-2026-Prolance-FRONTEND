import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProjectsRoutingModule } from './projects-routing.module';
import { ProjectsComponent } from './components/projects/projects.component';
import { ProjectFormComponent } from './components/project-form/project-form.component';

@NgModule({
  declarations: [ProjectsComponent, ProjectFormComponent],
  imports: [CommonModule, ReactiveFormsModule, FormsModule, ProjectsRoutingModule]
})
export class ProjectsModule {}
