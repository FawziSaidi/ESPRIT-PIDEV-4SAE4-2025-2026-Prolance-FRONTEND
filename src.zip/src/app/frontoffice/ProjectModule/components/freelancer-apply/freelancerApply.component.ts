import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { Project } from '../../models/project.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FreelancerService } from '../../services/freelancer.service';
import { AuthService } from '../../../../services/auth.services';

const SKILL_ICONS: Record<string, string> = {
  angular:    'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/angular/angular-original.svg',
  react:      'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg',
  vue:        'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vuejs/vuejs-original.svg',
  javascript: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg',
  typescript: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg',
  python:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg',
  java:       'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg',
  nodejs:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg',
  spring:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/spring/spring-original.svg',
  docker:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg',
  mysql:      'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg',
  mongodb:    'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg',
  figma:      'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg',
  git:        'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg',
  css:        'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg',
  html:       'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg',
  php:        'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg',
  flutter:    'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg',
  kotlin:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg',
  swift:      'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/swift/swift-original.svg',
  csharp:     'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg',
  'c#':       'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg',
  aws:        'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/amazonwebservices/amazonwebservices-original.svg',
};

@Component({
  selector: 'app-freelancer-apply',
  templateUrl: './freelancer-apply.component.html',
  styleUrls: ['./freelancer-apply.component.scss']
})
export class FreelancerApplyComponent implements OnInit {
  @Input() project?: Project;
  @Output() close = new EventEmitter<void>();
  @Output() applied = new EventEmitter<void>();

  currentStep: 'skills' | 'application' = 'skills';

  mySkills: any[] = [];
  selectedSkills: any[] = [];
  loadingSkills = true;

  form: FormGroup;

  coverLetterMode: 'text' | 'upload' | 'generate' | null = null;

  // Upload mode
  coverLetterFile: File | null = null;
  coverLetterFileName = '';
  isUploadingFile = false;
  /**
   * Après upload réussi :
   * - coverLetterRelativePath = "/uploads/cover-letters/xxx.pdf"  → envoyé en DB
   * - coverLetterPreviewUrl   = "http://localhost:8089/pidev/uploads/cover-letters/xxx.pdf" → preview
   */
  coverLetterRelativePath: string | null = null;
  coverLetterPreviewUrl: string | null = null;

  // Generate mode
  isGeneratingLetter = false;
  /**
   * Après génération :
   * - generatedRelativePath = "/uploads/cover-letters/cover_generated_1_xxx.pdf" → envoyé en DB
   * - generatedPreviewUrl   = "http://localhost:8089/pidev/uploads/..."  → preview
   */
  generatedRelativePath: string | null = null;
  generatedPreviewUrl: string | null = null;

  isSubmitting = false;
  currentUserId: number | null = null;

  // Base URL du backend pour construire les URLs de preview
  private readonly backendBase = 'http://localhost:8089/pidev';

  constructor(
    private fb: FormBuilder,
    private freelancerService: FreelancerService,
    private authService: AuthService
  ) {
    this.form = this.fb.group({
      coverLetter: ['', Validators.minLength(20)],
    });
  }

  ngOnInit(): void {
    const user = this.authService.getCurrentUser();
    this.currentUserId = user?.userId ?? null;
    this.loadMySkills();
  }

  loadMySkills(): void {
    if (!this.currentUserId) return;
    this.loadingSkills = true;
    this.freelancerService.getFreelancerSkills(this.currentUserId).subscribe({
      next: (skills) => { this.mySkills = skills; this.loadingSkills = false; },
      error: () => { this.loadingSkills = false; }
    });
  }

  getSkillIcon(name: string): string | null {
    return SKILL_ICONS[name?.toLowerCase()?.trim()] || null;
  }

  getInitial(name: string): string {
    return name?.charAt(0)?.toUpperCase() || '?';
  }

  toggleSkill(skill: any): void {
    const idx = this.selectedSkills.findIndex(s => s.id === skill.id);
    if (idx >= 0) this.selectedSkills.splice(idx, 1);
    else this.selectedSkills.push(skill);
  }

  isSkillSelected(skill: any): boolean {
    return this.selectedSkills.some(s => s.id === skill.id);
  }

  nextStep(): void {
    if (this.selectedSkills.length === 0) {
      alert('Please select at least one skill.');
      return;
    }
    this.currentStep = 'application';
  }

  // ─── Upload mode ─────────────────────────────────────────

  onCoverLetterFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.coverLetterFile = input.files[0];
      this.coverLetterFileName = input.files[0].name;
      // Reset si on change de fichier
      this.coverLetterRelativePath = null;
      this.coverLetterPreviewUrl = null;
    }
  }

  uploadCoverLetterFile(): void {
    if (!this.coverLetterFile || !this.currentUserId) return;
    this.isUploadingFile = true;

    this.freelancerService.uploadCoverLetter(this.currentUserId, this.coverLetterFile).subscribe({
      next: (relativePath: string) => {
        // relativePath = "/uploads/cover-letters/cover_1_xxx.pdf"
        this.coverLetterRelativePath = relativePath;
        this.coverLetterPreviewUrl   = `${this.backendBase}${relativePath}`;
        this.isUploadingFile = false;
      },
      error: (err) => {
        console.error('Upload error:', err);
        this.isUploadingFile = false;
        alert('Error uploading the file. Please try again.');
      }
    });
  }

  // ─── Generate mode ───────────────────────────────────────

  generateCoverLetter(): void {
    if (!this.currentUserId || !this.project?.id) return;
    this.isGeneratingLetter = true;
    this.generatedRelativePath = null;
    this.generatedPreviewUrl   = null;

    this.freelancerService.generateCoverLetterAsString(this.currentUserId, this.project.id).subscribe({
      next: (relativePath: string) => {
        // relativePath = "/uploads/cover-letters/cover_generated_1_xxx.pdf"
        this.generatedRelativePath = relativePath;
        this.generatedPreviewUrl   = `${this.backendBase}${relativePath}`;
        this.isGeneratingLetter = false;
      },
      error: (err) => {
        console.error('Generate error:', err);
        this.isGeneratingLetter = false;
        alert('Error generating cover letter. Make sure you have added skills first.');
      }
    });
  }

  // ─── Submit — toujours JSON ──────────────────────────────

  submitApplication(): void {
    if (!this.currentUserId || !this.project?.id) return;

    const hasText      = this.coverLetterMode === 'text'
                         && (this.form.value.coverLetter?.length ?? 0) >= 20;
    const hasUploaded  = this.coverLetterMode === 'upload'  && !!this.coverLetterRelativePath;
    const hasGenerated = this.coverLetterMode === 'generate' && !!this.generatedRelativePath;

    // L'utilisateur a choisi upload mais n'a pas encore cliqué Upload
    if (this.coverLetterMode === 'upload' && this.coverLetterFile && !this.coverLetterRelativePath) {
      alert('Please click "Upload" to upload your PDF before submitting.');
      return;
    }

    if (!hasText && !hasUploaded && !hasGenerated) {
      alert('Please provide a cover letter (write, upload a PDF, or generate one).');
      return;
    }

    this.isSubmitting = true;

    // Choisir la valeur à envoyer en DB :
    // - pour text : le texte lui-même
    // - pour upload/generate : le PATH RELATIF (ex: "/uploads/cover-letters/xxx.pdf")
    //   Le frontend stocke l'URL complète uniquement pour le preview local
    let coverLetterValue: string;
    if (hasText)           coverLetterValue = this.form.value.coverLetter;
    else if (hasUploaded)  coverLetterValue = this.coverLetterRelativePath!;
    else                   coverLetterValue = this.generatedRelativePath!;

    const payload = {
      freelancerId:   this.currentUserId,
      projectId:      this.project.id,
      coverLetterUrl: coverLetterValue   // ← nom exact attendu par le backend
    };

    this.freelancerService.submitApplication(payload).subscribe({
      next: () => this.onSuccess(),
      error: (err) => this.onError(err)
    });
  }

  private onSuccess(): void {
    this.isSubmitting = false;
    this.applied.emit();
    this.close.emit();
  }

  private onError(err: any): void {
    console.error(err);
    this.isSubmitting = false;
    alert(`Error ${err.status}: ${err.error?.message || 'Something went wrong.'}`);
  }

  closeModal(): void {
    this.close.emit();
  }
}