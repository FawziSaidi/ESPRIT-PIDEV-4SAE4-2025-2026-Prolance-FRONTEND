import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  searchQuery: string = '';

  constructor() { }

  ngOnInit(): void {
  }

  onSearch(): void {
    console.log('Recherche:', this.searchQuery);
  }
}
